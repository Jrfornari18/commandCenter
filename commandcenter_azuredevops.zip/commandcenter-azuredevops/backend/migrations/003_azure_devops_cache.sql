-- Migration: Azure DevOps cache tables for Command Center
-- Stores periodic snapshots for fast dashboard loading

CREATE TABLE IF NOT EXISTS devops_snapshots (
  id            SERIAL PRIMARY KEY,
  report_type   VARCHAR(50) NOT NULL,     -- 'weekly', 'quarter', 'epics', 'backlog', 'tags'
  report_data   JSONB NOT NULL,
  quarter       VARCHAR(10),              -- 'Q2-2026', 'Q3-2026'
  generated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_devops_snapshots_type ON devops_snapshots(report_type);
CREATE INDEX idx_devops_snapshots_quarter ON devops_snapshots(quarter);
CREATE INDEX idx_devops_snapshots_generated ON devops_snapshots(generated_at DESC);

CREATE TABLE IF NOT EXISTS devops_project_metrics (
  id            SERIAL PRIMARY KEY,
  project_name  VARCHAR(100) NOT NULL,
  period_label  VARCHAR(20) NOT NULL,     -- 'Abril', 'Maio', 'Junho', 'Q2-2026'
  created_count INTEGER NOT NULL DEFAULT 0,
  closed_count  INTEGER NOT NULL DEFAULT 0,
  throughput    DECIMAL(5,1),
  balance       INTEGER,
  snapshot_id   INTEGER REFERENCES devops_snapshots(id),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_devops_metrics_project ON devops_project_metrics(project_name);
CREATE INDEX idx_devops_metrics_period ON devops_project_metrics(period_label);

CREATE TABLE IF NOT EXISTS devops_epic_progress (
  id              SERIAL PRIMARY KEY,
  epic_id         INTEGER NOT NULL,
  epic_title      VARCHAR(200) NOT NULL,
  project         VARCHAR(100) NOT NULL,
  iteration       VARCHAR(100),
  total_items     INTEGER NOT NULL DEFAULT 0,
  done_items      INTEGER NOT NULL DEFAULT 0,
  pending_items   INTEGER NOT NULL DEFAULT 0,
  completion_pct  INTEGER NOT NULL DEFAULT 0,
  states_json     JSONB,
  snapshot_id     INTEGER REFERENCES devops_snapshots(id),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_devops_epics_project ON devops_epic_progress(project);

COMMENT ON TABLE devops_snapshots IS 'Cached Azure DevOps report snapshots for Command Center dashboard';
COMMENT ON TABLE devops_project_metrics IS 'Per-project per-period metrics from Azure DevOps';
COMMENT ON TABLE devops_epic_progress IS 'Epic completion tracking over time';
