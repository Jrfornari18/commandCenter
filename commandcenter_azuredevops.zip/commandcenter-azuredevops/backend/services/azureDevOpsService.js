/**
 * Azure DevOps Integration Service — Command Center
 * Copastur (org: copastur-dev) · API v7.1
 */
const https = require('https');

class AzureDevOpsService {
  constructor() {
    this.org = process.env.AZURE_DEVOPS_ORG || 'copastur-dev';
    this.pat = process.env.AZURE_DEVOPS_PAT;
    this.apiVersion = '7.1';
    this.baseUrl = `https://dev.azure.com/${this.org}`;
    this.batchSize = 200;
    this.maxResults = 1000;
    this.defaultFields = 'System.Id,System.Title,System.State,System.WorkItemType,System.AssignedTo,System.CreatedDate,System.ChangedDate,System.AreaPath,System.IterationPath,System.Tags,System.Parent,Microsoft.VSTS.Common.Priority';
    this.doneStates = ['Closed', 'Resolved', 'Tested'];
    this.monitoredProjects = [
      'Smart Client','VEGA CC','Cplus APP','Smart Operations','CopasLake',
      'INFRA CLOUD_SRE_ADMOPS_N1','Q2-2026','Zuri','Smart Integration',
      'AIFirst','ERP Benner','Segurança da Informação e Governança',
      'Eventos por Adesão','IA First','Copastur Energy (Forge-SinergIA)','Sales Force'
    ];
    this.strategyTags = ['SmartHotel','SmartSaving','Benner','Energy','ZURI','API Company','8BPay','Segurança','Niara'];
  }

  _auth() { return 'Basic ' + Buffer.from(`:${this.pat}`).toString('base64'); }

  async _request(method, url, body = null) {
    return new Promise((resolve, reject) => {
      const u = new URL(url);
      const opts = { hostname: u.hostname, path: u.pathname + u.search, method, timeout: 30000,
        headers: { 'Authorization': this._auth(), 'Content-Type': 'application/json' } };
      const req = https.request(opts, res => {
        let d = ''; res.on('data', c => d += c);
        res.on('end', () => { try { resolve({ data: JSON.parse(d), status: res.statusCode }); } catch { resolve({ data: { raw: d }, status: res.statusCode }); } });
      });
      req.on('error', reject); req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
      if (body) req.write(JSON.stringify(body)); req.end();
    });
  }

  async wiql(query) {
    const url = `${this.baseUrl}/_apis/wit/wiql?api-version=${this.apiVersion}&$top=${this.maxResults}`;
    const { data, status } = await this._request('POST', url, { query });
    return status === 200 && data.workItems ? data.workItems.map(w => String(w.id)) : [];
  }

  async wiqlCount(query) { return (await this.wiql(query)).length; }

  async fetchItems(ids, fields = null) {
    if (!ids.length) return [];
    const f = fields || this.defaultFields; const items = [];
    for (let i = 0; i < ids.length; i += this.batchSize) {
      const batch = ids.slice(i, i + this.batchSize).join(',');
      const { data, status } = await this._request('GET', `${this.baseUrl}/_apis/wit/workitems?ids=${batch}&fields=${f}&api-version=${this.apiVersion}`);
      if (status === 200 && data.value) items.push(...data.value);
    }
    return items;
  }

  gf(item, key) { return item?.fields?.[key]; }
  proj(item) { return (this.gf(item, 'System.AreaPath') || '').split('\\')[0]; }
  assignee(item) { const a = this.gf(item, 'System.AssignedTo'); return typeof a === 'object' ? a?.displayName || 'N/A' : a || 'N/A'; }
  isDone(s) { return this.doneStates.includes(s); }

  // ─── QUARTER REPORT (global monthly) ───
  async getQuarterReport(months) {
    const md = {}; let tCr = 0, tCl = 0;
    for (const { label, from, to } of months) {
      const ef = to > 0 ? ` AND [System.CreatedDate] < @Today - ${to}` : '';
      const ef2 = to > 0 ? ` AND [System.ChangedDate] < @Today - ${to}` : '';
      const cr = await this.wiqlCount(`SELECT [System.Id] FROM WorkItems WHERE [System.CreatedDate] >= @Today - ${from}${ef}`);
      const cl = await this.wiqlCount(`SELECT [System.Id] FROM WorkItems WHERE [System.State] IN ('Closed','Resolved','Tested') AND [System.ChangedDate] >= @Today - ${from}${ef2}`);
      md[label] = { created: cr, closed: cl, tp: Math.round(cl / Math.max(1, cr) * 100) };
      tCr += cr; tCl += cl;
    }
    return { totalCreated: tCr, totalClosed: tCl, throughput: +(tCl / Math.max(1, tCr) * 100).toFixed(1), monthly: md, at: new Date().toISOString() };
  }

  // ─── PER-PROJECT BREAKDOWN ───
  async getProjectBreakdown(months) {
    const results = [];
    for (const pn of this.monitoredProjects) {
      const pm = {}; let tc = 0, tl = 0;
      for (const { label, from, to } of months) {
        const pf = ` AND [System.TeamProject] = '${pn}'`;
        const ef = to > 0 ? ` AND [System.CreatedDate] < @Today - ${to}` : '';
        const ef2 = to > 0 ? ` AND [System.ChangedDate] < @Today - ${to}` : '';
        const cr = await this.wiqlCount(`SELECT [System.Id] FROM WorkItems WHERE [System.CreatedDate] >= @Today - ${from}${ef}${pf}`);
        const cl = await this.wiqlCount(`SELECT [System.Id] FROM WorkItems WHERE [System.State] IN ('Closed','Resolved','Tested') AND [System.ChangedDate] >= @Today - ${from}${ef2}${pf}`);
        pm[label] = { created: cr, closed: cl }; tc += cr; tl += cl;
      }
      if (tc > 0 || tl > 0) {
        const deltaMonths = Object.values(pm).map(m => m.closed);
        results.push({ project: pn, months: pm, totalCreated: tc, totalClosed: tl,
          throughput: +(tl / Math.max(1, tc) * 100).toFixed(1), balance: tl - tc,
          trend: deltaMonths.length >= 2 ? (deltaMonths[deltaMonths.length - 1] > deltaMonths[0] ? 'up' : 'down') : 'stable' });
      }
    }
    return results.sort((a, b) => (b.totalCreated + b.totalClosed) - (a.totalCreated + a.totalClosed));
  }

  // ─── EPICS HIERARCHY ───
  async getEpicsHierarchy(project = 'Q2-2026') {
    const ids = await this.wiql(`SELECT [System.Id] FROM WorkItems WHERE [System.TeamProject] = '${project}' ORDER BY [System.WorkItemType] ASC`);
    const items = await this.fetchItems(ids);
    const children = {};
    items.forEach(i => { const pid = this.gf(i, 'System.Parent'); if (pid) { (children[pid] = children[pid] || []).push(i); } });
    const getDesc = (pid) => { const d = []; (children[pid] || []).forEach(c => { d.push(c); d.push(...getDesc(this.gf(c, 'System.Id'))); }); return d; };

    const epics = items.filter(i => this.gf(i, 'System.WorkItemType') === 'Epic').map(ep => {
      const eid = this.gf(ep, 'System.Id'); const desc = getDesc(eid);
      const sc = {}; desc.forEach(d => { const s = this.gf(d, 'System.State') || '?'; sc[s] = (sc[s] || 0) + 1; });
      const done = this.doneStates.reduce((s, st) => s + (sc[st] || 0), 0);
      const rm = sc['Removed'] || 0; const tot = desc.length - rm;
      return { id: eid, title: this.gf(ep, 'System.Title'), state: this.gf(ep, 'System.State'),
        assignee: this.assignee(ep), iteration: (this.gf(ep, 'System.IterationPath') || '').replace(`${project}\\`, ''),
        descendants: desc.length, done, total: tot, pending: tot - done, completionPct: Math.round(done / Math.max(1, tot) * 100), states: sc };
    }).sort((a, b) => b.completionPct - a.completionPct || b.descendants - a.descendants);

    const td = epics.reduce((s, e) => s + e.total, 0); const dd = epics.reduce((s, e) => s + e.done, 0);
    return { project, totalItems: items.length, epics, global: { done: dd, total: td, pct: Math.round(dd / Math.max(1, td) * 100) } };
  }

  // ─── TAG LINKS ───
  async getTagLinks(tags = null) {
    const use = tags || this.strategyTags; const links = [];
    for (const tag of use) {
      const ids = await this.wiql(`SELECT [System.Id] FROM WorkItems WHERE [System.Tags] CONTAINS '${tag}' AND [System.State] <> 'Removed'`);
      if (!ids.length) continue;
      const items = await this.fetchItems(ids.slice(0, 500));
      const bp = {};
      items.forEach(i => { const p = this.proj(i); if (p !== 'Q2-2026') (bp[p] = bp[p] || []).push(i); });
      Object.entries(bp).forEach(([p, pi]) => {
        const done = pi.filter(i => this.isDone(this.gf(i, 'System.State'))).length;
        links.push({ tag, project: p, totalItems: pi.length, done, active: pi.length - done });
      });
    }
    return { total: links.reduce((s, l) => s + l.totalItems, 0), links: links.sort((a, b) => b.totalItems - a.totalItems) };
  }

  // ─── BACKLOG ───
  async getBacklog(project = null, minItems = 5) {
    const pf = project ? ` AND [System.TeamProject] = '${project}'` : '';
    const ids = await this.wiql(`SELECT [System.Id] FROM WorkItems WHERE [System.State] NOT IN ('Closed','Removed','Canceled','Cancelado','Tested') AND [System.ChangedDate] >= @Today - 180${pf}`);
    const items = await this.fetchItems(ids);
    const pd = {};
    items.forEach(i => {
      const p = this.proj(i); const s = this.gf(i, 'System.State');
      if (!pd[p]) pd[p] = { total: 0, new: 0, active: 0, inTest: 0, impediment: 0 };
      pd[p].total++;
      if (s === 'New') pd[p].new++; else if (s === 'Active') pd[p].active++;
      else if (['Waiting Test','In Test','Homologação'].includes(s)) pd[p].inTest++;
      else if (s === 'Impediment') pd[p].impediment++;
    });
    return { totalActive: ids.length,
      byProject: Object.entries(pd).filter(([, d]) => d.total >= minItems).sort((a, b) => b[1].total - a[1].total).map(([n, d]) => ({ project: n, ...d })) };
  }

  // ─── WEEKLY FULL REPORT ───
  async getWeeklyReport(months) {
    const [wCr, wCl, quarter, projects, epics, tags, backlog] = await Promise.all([
      this.wiqlCount("SELECT [System.Id] FROM WorkItems WHERE [System.CreatedDate] >= @Today - 7"),
      this.wiqlCount("SELECT [System.Id] FROM WorkItems WHERE [System.State] IN ('Closed','Resolved','Tested') AND [System.ChangedDate] >= @Today - 7"),
      this.getQuarterReport(months), this.getProjectBreakdown(months),
      this.getEpicsHierarchy('Q2-2026'), this.getTagLinks(), this.getBacklog(),
    ]);
    return { week: { created: wCr, closed: wCl, tp: Math.round(wCl / Math.max(1, wCr) * 100) },
      quarter, projects, epics, tagLinks: tags, backlog, at: new Date().toISOString() };
  }
}

module.exports = new AzureDevOpsService();
