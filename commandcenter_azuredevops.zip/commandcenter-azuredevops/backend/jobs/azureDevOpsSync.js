/**
 * Azure DevOps Sync Job — runs on schedule (cron)
 * Fetches all report data and caches in PostgreSQL
 */
const azureDevOps = require('../services/azureDevOpsService');

async function syncWeeklyReport(pool) {
  console.log('[AzureDevOps Sync] Starting weekly report sync...');
  const start = Date.now();

  try {
    // Dynamic month offsets
    const today = new Date();
    const apr1 = new Date(2026, 3, 1), may1 = new Date(2026, 4, 1), jun1 = new Date(2026, 5, 1);
    const msDay = 86400000;
    const months = [
      { label: 'Abril', from: Math.ceil((today - apr1) / msDay), to: Math.ceil((today - may1) / msDay) },
      { label: 'Maio', from: Math.ceil((today - may1) / msDay), to: Math.ceil((today - jun1) / msDay) },
      { label: 'Junho', from: Math.ceil((today - jun1) / msDay), to: 0 },
    ];

    const report = await azureDevOps.getWeeklyReport(months);

    // Save snapshot
    const { rows } = await pool.query(
      `INSERT INTO devops_snapshots (report_type, report_data, quarter, generated_at) 
       VALUES ($1, $2, $3, NOW()) RETURNING id`,
      ['weekly', JSON.stringify(report), 'Q2-2026']
    );
    const snapshotId = rows[0].id;

    // Save per-project metrics
    for (const proj of report.projects) {
      for (const [period, data] of Object.entries(proj.months)) {
        await pool.query(
          `INSERT INTO devops_project_metrics (project_name, period_label, created_count, closed_count, throughput, balance, snapshot_id) 
           VALUES ($1, $2, $3, $4, $5, $6, $7)`,
          [proj.project, period, data.created, data.closed, proj.throughput, proj.balance, snapshotId]
        );
      }
    }

    // Save epic progress
    for (const epic of report.epics.epics) {
      await pool.query(
        `INSERT INTO devops_epic_progress (epic_id, epic_title, project, iteration, total_items, done_items, pending_items, completion_pct, states_json, snapshot_id) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
        [epic.id, epic.title, report.epics.project, epic.iteration, epic.total, epic.done, epic.pending, epic.completionPct, JSON.stringify(epic.states), snapshotId]
      );
    }

    const elapsed = ((Date.now() - start) / 1000).toFixed(1);
    console.log(`[AzureDevOps Sync] Done in ${elapsed}s. Snapshot #${snapshotId}`);
    return { snapshotId, elapsed };
  } catch (err) {
    console.error('[AzureDevOps Sync] Error:', err.message);
    throw err;
  }
}

module.exports = { syncWeeklyReport };
