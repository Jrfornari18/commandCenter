/**
 * Azure DevOps API Routes — Command Center
 * Todas read-only. Write operations retornam requires_human_approval: true
 */
const express = require('express');
const router = express.Router();
const azureDevOps = require('../services/azureDevOpsService');

// Helper: calculate month offsets dynamically
function getQ2Months() {
  const today = new Date();
  const apr1 = new Date(2026, 3, 1), may1 = new Date(2026, 4, 1), jun1 = new Date(2026, 5, 1);
  const msDay = 86400000;
  return [
    { label: 'Abril', from: Math.ceil((today - apr1) / msDay), to: Math.ceil((today - may1) / msDay) },
    { label: 'Maio', from: Math.ceil((today - may1) / msDay), to: Math.ceil((today - jun1) / msDay) },
    { label: 'Junho', from: Math.ceil((today - jun1) / msDay), to: 0 },
  ];
}

// GET /api/azure-devops/health
router.get('/health', async (req, res) => {
  try {
    const count = await azureDevOps.wiqlCount(
      "SELECT [System.Id] FROM WorkItems WHERE [System.CreatedDate] >= @Today - 1"
    );
    res.json({ status: 'connected', org: azureDevOps.org, itemsToday: count, at: new Date().toISOString() });
  } catch (err) {
    res.status(503).json({ status: 'error', error: err.message });
  }
});

// GET /api/azure-devops/quarter?period=q2
router.get('/quarter', async (req, res) => {
  try {
    const months = getQ2Months();
    const data = await azureDevOps.getQuarterReport(months);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/azure-devops/projects?period=q2
router.get('/projects', async (req, res) => {
  try {
    const months = getQ2Months();
    const data = await azureDevOps.getProjectBreakdown(months);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/azure-devops/epics?project=Q2-2026
router.get('/epics', async (req, res) => {
  try {
    const project = req.query.project || 'Q2-2026';
    const data = await azureDevOps.getEpicsHierarchy(project);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/azure-devops/tags
router.get('/tags', async (req, res) => {
  try {
    const tags = req.query.tags ? req.query.tags.split(',') : null;
    const data = await azureDevOps.getTagLinks(tags);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/azure-devops/backlog?project=Cplus+APP&min=5
router.get('/backlog', async (req, res) => {
  try {
    const { project, min } = req.query;
    const data = await azureDevOps.getBacklog(project || null, parseInt(min) || 5);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/azure-devops/weekly — Full weekly report
router.get('/weekly', async (req, res) => {
  try {
    const months = getQ2Months();
    const data = await azureDevOps.getWeeklyReport(months);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/azure-devops/query — Custom WIQL
router.get('/query', async (req, res) => {
  try {
    const { type, days, project, workItemType, state, tag } = req.query;
    const d = parseInt(days) || 7;
    const conds = [];
    if (type === 'created') conds.push(`[System.CreatedDate] >= @Today - ${d}`);
    else if (type === 'closed') { conds.push("[System.State] IN ('Closed','Resolved','Tested')"); conds.push(`[System.ChangedDate] >= @Today - ${d}`); }
    else conds.push(`[System.ChangedDate] >= @Today - ${d}`);
    if (project) conds.push(`[System.TeamProject] = '${project}'`);
    if (workItemType) conds.push(`[System.WorkItemType] = '${workItemType}'`);
    if (state) conds.push(`[System.State] = '${state}'`);
    if (tag) conds.push(`[System.Tags] CONTAINS '${tag}'`);
    conds.push("[System.State] <> 'Removed'");

    const q = `SELECT [System.Id] FROM WorkItems WHERE ${conds.join(' AND ')} ORDER BY [System.ChangedDate] DESC`;
    const ids = await azureDevOps.wiql(q);
    const items = await azureDevOps.fetchItems(ids.slice(0, 200));
    const mapped = items.map(i => ({
      id: azureDevOps.gf(i, 'System.Id'), title: azureDevOps.gf(i, 'System.Title'),
      state: azureDevOps.gf(i, 'System.State'), type: azureDevOps.gf(i, 'System.WorkItemType'),
      assignee: azureDevOps.assignee(i), project: azureDevOps.proj(i),
      iteration: azureDevOps.gf(i, 'System.IterationPath'), tags: azureDevOps.gf(i, 'System.Tags'),
      priority: azureDevOps.gf(i, 'Microsoft.VSTS.Common.Priority'),
      created: azureDevOps.gf(i, 'System.CreatedDate'), changed: azureDevOps.gf(i, 'System.ChangedDate'),
    }));
    res.json({ total: ids.length, items: mapped, query: q });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
