# Azure DevOps Integration — Command Center

## Adicionar ao app Express existente

### 1. Instalar dependências (nenhuma extra — usa `https` nativo)

### 2. Adicionar rota no `server.js` / `app.js`:

```javascript
const azureDevOpsRoutes = require('./routes/azureDevOpsRoutes');
app.use('/api/azure-devops', azureDevOpsRoutes);
```

### 3. Adicionar env vars no `.env`:

```
AZURE_DEVOPS_ORG=copastur-dev
AZURE_DEVOPS_PAT=<seu_pat_aqui>
```

### 4. Rodar migration:

```bash
psql $DATABASE_URL -f migrations/003_azure_devops_cache.sql
```

### 5. Agendar sync job (node-cron ou similar):

```javascript
const cron = require('node-cron');
const { syncWeeklyReport } = require('./jobs/azureDevOpsSync');

// Segunda-feira 8h (horário Brasília)
cron.schedule('0 11 * * 1', () => syncWeeklyReport(pool));
```

## Endpoints disponíveis

| Endpoint | Descrição |
|---|---|
| `GET /api/azure-devops/health` | Teste de conexão |
| `GET /api/azure-devops/quarter` | KPIs globais Q2 com evolução mensal |
| `GET /api/azure-devops/projects` | Ranking de projetos com breakdown mensal |
| `GET /api/azure-devops/epics?project=Q2-2026` | Epics com completude hierárquica |
| `GET /api/azure-devops/tags` | Vínculos estratégia→execução via tags |
| `GET /api/azure-devops/backlog` | Backlog ativo por projeto |
| `GET /api/azure-devops/weekly` | Relatório semanal completo (todos os dados) |
| `GET /api/azure-devops/query?type=created&days=7` | Query customizada |

## Segurança

- PAT sempre via variável de ambiente (NUNCA hardcoded)
- Todos os endpoints são READ-ONLY
- Write operations retornam `requires_human_approval: true`
- Autenticação via Entra ID (tenant 5ffc8daf-...)
