/**
 * Azure DevOps API Client — Frontend
 */
const API_BASE = '/api/azure-devops';

async function fetchJson(path) {
  const res = await fetch(`${API_BASE}${path}`, { credentials: 'include' });
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  return res.json();
}

export const azureDevOpsApi = {
  health:    ()               => fetchJson('/health'),
  quarter:   ()               => fetchJson('/quarter'),
  projects:  ()               => fetchJson('/projects'),
  epics:     (project)        => fetchJson(`/epics?project=${encodeURIComponent(project || 'Q2-2026')}`),
  tags:      (tags)           => fetchJson(`/tags${tags ? `?tags=${tags.join(',')}` : ''}`),
  backlog:   (project, min)   => fetchJson(`/backlog?${project ? `project=${encodeURIComponent(project)}&` : ''}min=${min || 5}`),
  weekly:    ()               => fetchJson('/weekly'),
  query:     (params)         => fetchJson(`/query?${new URLSearchParams(params)}`),
};
