import { useState, useEffect, useCallback } from 'react';
import { azureDevOpsApi } from '../services/azureDevOpsApi';

export function useAzureDevOps(endpoint, params = null) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const fn = azureDevOpsApi[endpoint];
      if (!fn) throw new Error(`Unknown endpoint: ${endpoint}`);
      const result = params ? await fn(params) : await fn();
      setData(result);
    } catch (err) { setError(err.message); }
    finally { setLoading(false); }
  }, [endpoint, JSON.stringify(params)]);

  useEffect(() => { load(); }, [load]);
  return { data, loading, error, reload: load };
}
